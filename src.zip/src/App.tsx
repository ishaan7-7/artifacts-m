import { HashRouter, Routes, Route } from 'react-router-dom';
import { ThemeProvider } from '@mui/material/styles';
import { CssBaseline } from '@mui/material';
import Layout from './components/Layout';
import WriterOps from './pages/WriterOps';
import GoldHealth from './pages/GoldHealth';
import AutomotiveDive from './pages/AutomotiveDive';
import DashboardInference from './pages/DashboardInference';
import DashboardAlerts from './pages/DashboardAlerts';
import DtcInvestigation from './pages/DtcInvestigation';
import { useStore } from './store';
import { lightTheme, darkTheme } from './theme';

function App() {
  const darkMode = useStore((s) => s.darkMode);

  return (
    <ThemeProvider theme={darkMode ? darkTheme : lightTheme}>
      <CssBaseline />
      <HashRouter>
        <Routes>
          <Route path="/" element={<Layout />}>
            <Route index element={<WriterOps />} />
            <Route path="inference" element={<DashboardInference />} />
            <Route path="gold" element={<GoldHealth />} />
            <Route path="alerts" element={<DashboardAlerts />} />
            <Route path="automotive" element={<AutomotiveDive />} />
            <Route path="dtc" element={<DtcInvestigation />} />
          </Route>
        </Routes>
      </HashRouter>
    </ThemeProvider>
  );
}

export default App;
